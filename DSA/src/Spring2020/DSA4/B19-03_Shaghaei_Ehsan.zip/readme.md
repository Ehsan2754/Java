# DSA Assignment1
## Ehsan Shaghaei
### B19-03 

# TASK 1 and 2 file

>DSA4TASK1and2.java

#TASK 3 -PHONEBOOK
[CodeFores Submission](https://codeforces.com/group/3ZU2JJw8vQ/contest/269072/my#)
>DSA4-TASK3
[CodeFores Submission](https://codeforces.com/group/3ZU2JJw8vQ/contest/269072/my#)

