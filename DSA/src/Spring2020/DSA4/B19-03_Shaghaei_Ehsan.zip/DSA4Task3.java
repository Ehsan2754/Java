package Spring2020.DSA4;

import java.util.*;
import java.util.function.Predicate;

public class DSA4Task3 {
    public static HashMap<String, String> phoneBook = new HashMap<>();

    public static void main(String[] args) {
        Scanner user = new Scanner(System.in);
        int nCMD = user.nextInt();
        user.nextLine();
        for (int i = 0; i < nCMD; i++) {
            applyCMD(user.nextLine().split(","));
        }
    }

    public static void applyCMD(final String[] cmd) throws IllegalArgumentException {
        String[] aCMD = cmd[0].split(" ");

        switch (aCMD[0]) {
            case "ADD":
                phoneBook.put(getPhoneNumber(cmd), getFullName(aCMD));
                break;
            case "DELETE":
                if (cmd.length > 1) {
                    phoneBook.remove(getPhoneNumber(cmd), getFullName(aCMD));
                } else if (cmd.length == 1) {
                    phoneBook.entrySet().removeIf(names -> names.getValue().equals(getFullName(aCMD)));
                }
                break;
            case "FIND":
                ArrayList<String> numbers = new ArrayList<>();
                for (Map.Entry<String, String> entry
                        : phoneBook.entrySet()) {
                    if (entry.getValue().equals(getFullName(aCMD))) numbers.add(entry.getKey());
                }
                if (numbers.isEmpty()) System.out.println("No contact info found for " + getFullName(aCMD));
                else {
                    String numbersString = "";
                    for (String s
                            : numbers) {
                        numbersString += " " + s;
                    }
                    System.out.println(String.format("Found %d phone numbers for %s:%s",
                            numbers.size(),
                            getFullName(aCMD),
                            numbersString));
                }

                break;
        }

    }


    static String getFullName(final String[] aCMD) {
        String fullName = "";
        for (int i = 1; i < aCMD.length; i++) {
            if (i == 1) fullName = aCMD[1];
            else
                fullName += " " + aCMD[i];
        }
        return fullName;
    }

    static String getPhoneNumber(final String[] cmd) {

        return cmd[1];

    }
}
