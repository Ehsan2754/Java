# DSA Assignment1
## Ehsan Shaghaei
###E.Shaghaei@innopolis.university
#### Group B19-03 

# TASK 1 and 2 file 

##### List ADT, Dynamic Array List implementation, Doubly Linked Array implementation

>DSA4TASK1and2.java

[CodeFores Submission for Task 1 and 2](https://codeforces.com/group/3ZU2JJw8vQ/contest/269072/submission/71284077)

#TASK 3 

##### Phone Book

>DSA4-Task4.java

[CodeFores Submission for Task 3](https://codeforces.com/group/3ZU2JJw8vQ/contest/269072/submission/71344232)

